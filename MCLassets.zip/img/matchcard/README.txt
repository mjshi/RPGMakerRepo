Included are the bare essential assets needed
for this plugin to function.

All images in here MUST go in img/matchcard/

and the optional Book1_fast.ogg is included for your use.
Place that in the audio/se/ folder if you so choose.
(The vanilla Book1 sound effect is a bit too slow)