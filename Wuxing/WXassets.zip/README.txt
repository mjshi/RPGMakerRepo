Included are the bare essential assets needed
for this plugin to function.

Simply move the two folders into the base directory
of your project and the files should move themselves
into the appropriate folders.

(base directory = where your Game.rpgproject file is)